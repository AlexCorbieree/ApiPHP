<?php


$debug      = false;
$key        = "12345";
$datos      = 'kardex/kardex.php';
$conexion = array( 
    "servername" => "localhost",
    "username"   => "root",
    "password"   => "",
    "dbname"     => "examen2"
);