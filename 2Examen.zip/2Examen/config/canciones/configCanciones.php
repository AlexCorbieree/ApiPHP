<?php


$debug      = false;
$key        = "12345";
$datos      = 'canciones/canciones.php';
$conexion = array( 
    "servername" => "localhost",
    "username"   => "root",
    "password"   => "",
    "dbname"     => "examen2"
);