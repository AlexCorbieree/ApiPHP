<?php
$debug = true;
$key = "12345";
$conexion = array(
    "servername"=>"localhost",
    "username"=> "root",
    "password"=>"",
    "dbname"=>"proyecto"
);
$datos = 'login/login.php';