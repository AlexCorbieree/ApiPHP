<?php
$debug      = true;
$key        = "12345";
$datos      = "perfiles/perfiles.php";

$conexion = array(
    "servername" => "localhost",
    "username"   => "root",
    "password"   => "",
    "dbname"     => "proyecto"
);
$datos = 'perfiles/perfiles.php';